#Array with available choices
  choices = ["rock", "paper", "scissors"]

#Computer's choice
  computer_choice = choices.sample

#Ask about user's choice
  puts "Please, choose a sign (rock, scissors, or paper):"
  user_choice = gets.chomp.downcase

#Check if the user's input is valid and if input's not correct, we are adding an error message
unless choices.include?(user_choice)
  puts "Please, choose a valid sign (rock, scissors, or paper)!"
  exit
end

#Comparison the user's and computer's choices
  puts "Your choice: #{user_choice}"
  puts "Computer's choice: #{computer_choice}"

#Check the game result
if user_choice == computer_choice
  puts "It turned out to be a draw!"
elsif (user_choice == "rock" && computer_choice == "scissors") ||
  (user_choice == "scissors" && computer_choice == "paper") ||
  (user_choice == "paper" && computer_choice == "rock")
  puts "Congratulations, you win!"
else
  puts "Oops, you lose!"
end